package com.example.tictactoe

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var buttons: Array<Array<Button>>
    private var playerXTurn = true
    private var roundCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttons = Array(3) { row ->
            Array(3) { col ->
                val buttonId = "button_${row}${col}"
                val resId = resources.getIdentifier(buttonId, "id", packageName)
                findViewById<Button>(resId).apply {
                    setOnClickListener { onButtonClick(this) }
                }
            }
        }

        val resetButton: Button = findViewById(R.id.button_reset)
        resetButton.setOnClickListener { resetGame() }
    }

    private fun onButtonClick(button: Button) {
        if (button.text.isNotEmpty()) return

        button.text = if (playerXTurn) "X" else "O"
        roundCount++

        if (checkForWin()) {
            val winner = if (playerXTurn) "X gana!" else "O gana!"
            findViewById<TextView>(R.id.text_view_result).text = winner
            disableButtons()
        } else if (roundCount == 9) {
            findViewById<TextView>(R.id.text_view_result).text = "Empate!"
        } else {
            playerXTurn = !playerXTurn
        }
    }

    private fun checkForWin(): Boolean {
        val field = Array(3) { row ->
            Array(3) { col -> buttons[row][col].text.toString() }
        }

        for (i in 0..2) {
            if (field[i][0] == field[i][1] && field[i][0] == field[i][2] && field[i][0].isNotEmpty())
                return true
        }

        for (i in 0..2) {
            if (field[0][i] == field[1][i] && field[0][i] == field[2][i] && field[0][i].isNotEmpty())
                return true
        }

        if (field[0][0] == field[1][1] && field[0][0] == field[2][2] && field[0][0].isNotEmpty())
            return true

        if (field[0][2] == field[1][1] && field[0][2] == field[2][0] && field[0][2].isNotEmpty())
            return true

        return false
    }

    private fun disableButtons() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].isEnabled = false
            }
        }
    }

    private fun resetGame() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].text = ""
                buttons[i][j].isEnabled = true
            }
        }
        roundCount = 0
        playerXTurn = true
        findViewById<TextView>(R.id.text_view_result).text = ""
    }
}
